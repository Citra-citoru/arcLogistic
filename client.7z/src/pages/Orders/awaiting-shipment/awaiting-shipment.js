import React from 'react';
import './awaiting-shipment.scss';

export default() =>(
<React.Fragment>
    <p className={'content-block'}>awaiting shipment page on progress</p>
</React.Fragment>
);