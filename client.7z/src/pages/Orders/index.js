export { default as ShippedPage } from './shipped/shipped';
export { default as AwaitingPaymentPage } from './awaiting-payment/awaiting-payment';
export { default as OnHoldPage } from './onhold/onhold';
export { default as AwaitingShipmentPage } from './awaiting-shipment/awaiting-shipment';
export { default as  OrderedAlertPage} from './ordered-alert/ordered-alert';
export { default as  CanceledPage} from './canceled/canceled';
export { default as  ProfilePage} from './profile/profile';