import React from 'react';
import './onhold.scss';

export default ()=>(
    <React.Fragment>
        <p className="content-block">On Hold Pages in Progress</p>
    </React.Fragment>
);