import React from 'react';
import './index.scss';

export default function archived(){
return(
<p>processed page is working</p>


)};