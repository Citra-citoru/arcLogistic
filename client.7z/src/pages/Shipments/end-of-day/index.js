import React from 'react';
import './index.scss';

export default function archived(){
return(
<p>end of page is working</p>


)};