import React from 'react';
import './index.scss';

export default function archived(){
return(
<p>returns page is working</p>


)};