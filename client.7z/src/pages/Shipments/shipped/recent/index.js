import React from 'react';
import './index.scss';

export default function(){
return(
<p>recent page is working</p>


)};