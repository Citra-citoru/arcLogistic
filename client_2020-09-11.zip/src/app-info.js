export default {
  title: 'ARC Logistic'
};
