import {withNavigationWatcher} from './contexts/navigation';
import {
    AwaitingPaymentPage,
    OnHoldPage,
    ShippedPage,
    AwaitingShipmentPage,
    OrderedAlertPage,
    CanceledPage,
    ProfilePage
} from '../../../pages';

const InsightRoutes = [];
