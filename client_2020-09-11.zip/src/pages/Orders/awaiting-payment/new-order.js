import React from 'react';
import 'devextreme-react/text-area';
import ScrollView from 'devextreme-react/scroll-view';
import {Button} from 'devextreme-react/button';
import Form, {
    Item,
    Label,
    ButtonItem,
    ButtonOptions,
    RequiredRule,
    EmailRule
  } from 'devextreme-react/form';

export default function NewOrder() {
  return(
    <ScrollView width='100%' height='100%'>
    <div className="form-container">
    <Form className={'create-account-form'} colCount={2} id="form">
    <p>Recipient Information:</p>
      <Item editorType={'dxTextBox'} dataField={'Name'} editorOptions={nameEditorOptions}>
        <Label visible={false} />
      </Item>
      <Item dataField="Paste US Address" colSpan={2} editorType="dxTextArea"  editorOptions={pasteUSAddress}> 
        <Label visible={false} />
      </Item>
      <Item dataField="Company" editorOptions={company}>
      <Label visible={false} />
      </Item>
      <Item dataField="Address" editorOptions={address}>
      <Label visible={false} />
      </Item>
      <Item dataField="City" editorOptions={city}>
        <Label visible={false} />
      </Item>
      <Item dataField="State" editorOptions={state}>
        <Label visible={false} />
      </Item>
      <Item dataField="Postal Code" editorOptions={postalcode}>
        <Label visible={false} />
      </Item>
      <Item dataField="Country" editorOptions={country}>
        <Label visible={false} />
      </Item>
      <Item dataField="Phone" editorOptions={phone}>
        <Label visible={false} />
      </Item>
      <Item dataField="Email" editorOptions={emailEditorOptions}>
        <Label visible={false} />
      </Item>
    </Form>
    <div className="action-button">
        <div><Button className="m-3" text={'Cancel'}/> </div> 
        <div><Button className="m-3" type={'default'} text={'Save Orders'}/></div>
    </div>
  </div>
  </ScrollView>
  );
}
const nameEditorOptions = { stylingMode: 'filled', placeholder: 'Name', mode: 'name' };
const pasteUSAddress = { stylingMode: 'filled', placeholder: 'paste US Address', mode: 'pasteUSAddress' };
const company = { stylingMode: 'filled', placeholder: 'company', mode: 'company' };
const address = { stylingMode: 'filled', placeholder: 'address', mode: 'address' };
const city = { stylingMode: 'filled', placeholder: 'city', mode: 'city' };
const emailEditorOptions = { stylingMode: 'filled', placeholder: 'Email', mode: 'email' };
const state = { stylingMode: 'filled', placeholder: 'state', mode: 'state' };
const postalcode = { stylingMode: 'filled', placeholder: 'postalcode', mode: 'postalcode' };
const phone = { stylingMode: 'filled', placeholder: 'phone', mode: 'phone' };
const country = { stylingMode: 'filled', placeholder: 'country', mode: 'country' };
