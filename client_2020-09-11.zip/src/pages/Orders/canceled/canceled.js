import React from 'react';
import './canceled.scss';

export default () => (
    <p className={'content-block'}>Canceled Page in progress</p>
);