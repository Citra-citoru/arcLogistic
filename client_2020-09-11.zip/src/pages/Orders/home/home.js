import React from 'react';
import './home.scss';

export default () => (
  <React.Fragment>
   <h2>Test Home</h2>
  </React.Fragment>
);
