import React from 'react';
import './ordered-alert.scss';

export default () => (
    <p className={'content-block'}>Ordered Alert Page on Progress</p>
);