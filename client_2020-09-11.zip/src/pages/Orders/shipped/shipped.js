import React from 'react';
import './shipped.scss';

export default() =>(
<React.Fragment>
    <p className={'content-block'}>shipped page in progress</p>
</React.Fragment>
);