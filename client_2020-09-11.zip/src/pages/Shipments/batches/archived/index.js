import React from 'react';
import './index.scss';

export default function(){
return(
<p>archived page is working</p>


)};