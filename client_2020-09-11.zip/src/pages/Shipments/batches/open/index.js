import React from 'react';
import './index.scss';

export default function archived(){
return(
<p>open page is working</p>


)};