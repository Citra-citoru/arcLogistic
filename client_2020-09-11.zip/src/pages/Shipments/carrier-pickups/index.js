import React from 'react';
import './index.scss';

export default function archived(){
return(
<p>carried page is working</p>


)};