import React from 'react';
import './index.scss';

export default function archived(){
return(
<p>in transit page is working</p>


)};