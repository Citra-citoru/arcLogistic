import React from 'react';
import './index.scss';

export default function Voided(){
return(
<p>voided page is working</p>
  

)};