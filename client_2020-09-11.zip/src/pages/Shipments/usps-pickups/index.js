import React from 'react';
import './index.scss';

export default function UspsPickups(){
return(
<p>usps pickups page is working</p>


)};